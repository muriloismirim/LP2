﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        int i = 0;
        int j = 0;
        int[,] vendas = new int[4,4];
        string aux = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j=0; j<4; j++)
                {
                    aux = Interaction.InputBox($"Digite a venda da semana {j + 1} para o mês {i + 1}", "Entrada de Dados");
                    if (!int.TryParse(aux, out vendas[i, j]))
                    {
                        MessageBox.Show("valor inválido");
                        j--;
                    }
                    else
                        if (vendas[i, j] < 0 || vendas[i, j] > 10)
                    {
                        MessageBox.Show("valor inválido");
                        j--;
                    }

                }
            }

            int[] totalSemana = new int[4];
            int[] totalMes = new int[4];
            int totalGeral = 0;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    totalSemana[j] += vendas[i, j];
                }
                totalMes[i] = totalSemana[0] + totalSemana[1] + totalSemana[2] + totalSemana[3];
                totalGeral += totalMes[i];                
            }


            ltb1.Items.Add("Total vendido na semana 1: " + totalSemana[0]);
            ltb1.Items.Add("Total vendido na semana 2: " + totalSemana[1]);
            ltb1.Items.Add("Total vendido na semana 3: " + totalSemana[2]);
            ltb1.Items.Add("Total vendido na semana 4: " + totalSemana[3]);
            ltb1.Items.Add("Total vendido no mês 1: " + totalMes[0]);
            ltb1.Items.Add("Total vendido no mês 2: " + totalMes[1]);
            ltb1.Items.Add("Total vendido no mês 3: " + totalMes[2]);
            ltb1.Items.Add("Total vendido no mês 4: " + totalMes[3]);
            ltb1.Items.Add("Total vendido em todos os meses: " + totalGeral);
        }
    }
}
