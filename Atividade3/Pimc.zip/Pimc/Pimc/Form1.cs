﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Peso inválido!");
                txtPeso.Focus();
            }
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida!");
                txtAltura.Focus();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            txtIMC.Text = imc.ToString();

            if (imc < 18.5)
                MessageBox.Show("Magreza");
            else if (imc <= 24.9)
                MessageBox.Show("Normal");
            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso");
            else if (imc <= 39.9)
                MessageBox.Show("Sobrepeso");
            else
                MessageBox.Show("Obesidade Grave");
        }
                
        

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Text = "";
            txtAltura.Text = "";
            txtIMC.Text = "";
        }
    }
}
