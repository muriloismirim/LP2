﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            int[] Nvetor = new int[20]; 
            string saida = "";
            string aux = "";
            for (var i =0; i<20; i++)
            {
                aux = Interaction.InputBox($"Digite número {i++}º", "Entrada de Dados");
                if (aux == "")
                    return;
                if(!int.TryParse(aux, out Nvetor[i]))
                {
                    MessageBox.Show("valor é inválido");
                    i--;
                }
                else
                {
                    saida =Nvetor[i]+"\n"+saida;
                }
            }
            MessageBox.Show(saida);
 
            Array.Reverse(Nvetor);
            aux = "";
            foreach(var x in Nvetor)
            {
                aux += x+"\n";
                

            }
            MessageBox.Show(aux);
            aux = "";
            for(var x = 19; x >= 0; x--)
            {
                aux += Nvetor[x] + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            double[,] vetNotas= new double[20,3];
            double[] med = new double[20];
            string auxiliar = "";
            for(int i=0;i<20;i++)
                for(int j = 0; j < 3; j++)
                {
                    auxiliar=Interaction.InputBox($"Digite a nota {j+1}º para o aluno{i+1}", "Entrada de Dados");
                    if (!Double.TryParse(auxiliar, out vetNotas[i, j]))
                    {
                        MessageBox.Show("valor inválido");
                        j--;
                    }
                    else
                        if(vetNotas[i, j]<0|| vetNotas[i, j] > 10)
                    {
                        MessageBox.Show("valor inválido");
                        j--;
                    }
                      

                }
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    med[i] = med[i]+ vetNotas[i,j];
                }
                med[i] = med[i] / 3;
            }
            string saida = "";
            for (var x =0; x<20; x++)
            {
                saida += $"Aluno {x+ 1}: {med[x]:F2}\n";
            }
                MessageBox.Show(saida);


        }

        private void btn3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Álvaro", "Ana", "Beto", "Clara", "Dani",
                "Enzo", "Lia", "Lucas", "Rafael"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            ArrayList alunos =new ArrayList() { "Ana", "Pedro", "Isabela", "Camila", "Rafael", "Luís", "Miguel", "Guilherme", "Gabriel" };
            alunos.Remove("Miguel");
            string novaSaida = ""; 
            foreach(var x in alunos)
            {
                novaSaida+=x.ToString()+"; \n";
            }
            MessageBox.Show(novaSaida);

        }

        private void btn5_Click(object sender, EventArgs e)
        {
          

           Form2 form2 = new Form2();
           form2.Show();
        }
    }
}
