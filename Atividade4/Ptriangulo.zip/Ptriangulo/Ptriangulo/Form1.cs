﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;
        
        private void txtA_Validated(object sender, EventArgs e)
        {

            errorProvider1.SetError(txtA, "");
            
            if (!Double.TryParse(txtA.Text, out A))
            {
                errorProvider1.SetError(txtA, "Lado A inválido");
                txtA.Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtB, "");

            if (!Double.TryParse(txtB.Text, out B))
            {
                errorProvider1.SetError(txtB, "Lado B inválido");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtC, "");

            if (!Double.TryParse(txtC.Text, out C))
            {
                errorProvider1.SetError(txtC, "Lado C inválido");
                txtC.Focus();
            }
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if (A < (B + C) && A > Math.Abs(B - C) && B < (A + C) && B > Math.Abs(A - C) && C > Math.Abs(A - B))
            {
                if (A == B && B == C)
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else
                {
                    if(A == B || B == C || A == C)
                    {
                        MessageBox.Show("Triângulo Isósceles");
                    }
                    else
                    {
                        MessageBox.Show("Triângulo Escaleno");
                    }
                }
            }
            else
            {
                MessageBox.Show("Os valores não formam um triângulo");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Text = "";
            txtB.Text = "";
            txtC.Text = "";
            A = 0;
            B = 0;
            C = 0;
        }
    }
}
