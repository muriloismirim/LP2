﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblBruto = new System.Windows.Forms.Label();
            this.lblNFilhos = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.lblDesINSS = new System.Windows.Forms.Label();
            this.txtDesINSS = new System.Windows.Forms.TextBox();
            this.lblDesIRPF = new System.Windows.Forms.Label();
            this.txtDesIRPF = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtLiquido = new System.Windows.Forms.TextBox();
            this.mskbxNome = new System.Windows.Forms.MaskedTextBox();
            this.txtBruto = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(13, 13);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(105, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do funcionário";
            // 
            // lblBruto
            // 
            this.lblBruto.AutoSize = true;
            this.lblBruto.Location = new System.Drawing.Point(13, 54);
            this.lblBruto.Name = "lblBruto";
            this.lblBruto.Size = new System.Drawing.Size(67, 13);
            this.lblBruto.TabIndex = 1;
            this.lblBruto.Text = "Salário Bruto";
            // 
            // lblNFilhos
            // 
            this.lblNFilhos.AutoSize = true;
            this.lblNFilhos.Location = new System.Drawing.Point(13, 93);
            this.lblNFilhos.Name = "lblNFilhos";
            this.lblNFilhos.Size = new System.Drawing.Size(86, 13);
            this.lblNFilhos.TabIndex = 2;
            this.lblNFilhos.Text = "Número de filhos";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(124, 126);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(128, 32);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(124, 91);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 7;
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(16, 181);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(73, 13);
            this.lblAliqINSS.TabIndex = 8;
            this.lblAliqINSS.Text = "Aliquota INSS";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Location = new System.Drawing.Point(16, 220);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblAliqIRPF.TabIndex = 9;
            this.lblAliqIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(17, 254);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(73, 13);
            this.lblSalFamilia.TabIndex = 10;
            this.lblSalFamilia.Text = "Salário família";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(16, 287);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(76, 13);
            this.lblSalLiquido.TabIndex = 11;
            this.lblSalLiquido.Text = "Salário Liquido";
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Location = new System.Drawing.Point(124, 178);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(181, 20);
            this.txtAliqINSS.TabIndex = 12;
            // 
            // lblDesINSS
            // 
            this.lblDesINSS.AutoSize = true;
            this.lblDesINSS.Location = new System.Drawing.Point(345, 181);
            this.lblDesINSS.Name = "lblDesINSS";
            this.lblDesINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDesINSS.TabIndex = 13;
            this.lblDesINSS.Text = "Desconto INSS";
            // 
            // txtDesINSS
            // 
            this.txtDesINSS.Location = new System.Drawing.Point(441, 178);
            this.txtDesINSS.Name = "txtDesINSS";
            this.txtDesINSS.Size = new System.Drawing.Size(181, 20);
            this.txtDesINSS.TabIndex = 14;
            // 
            // lblDesIRPF
            // 
            this.lblDesIRPF.AutoSize = true;
            this.lblDesIRPF.Location = new System.Drawing.Point(345, 220);
            this.lblDesIRPF.Name = "lblDesIRPF";
            this.lblDesIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDesIRPF.TabIndex = 15;
            this.lblDesIRPF.Text = "Desconto IRPF";
            // 
            // txtDesIRPF
            // 
            this.txtDesIRPF.Location = new System.Drawing.Point(441, 213);
            this.txtDesIRPF.Name = "txtDesIRPF";
            this.txtDesIRPF.Size = new System.Drawing.Size(181, 20);
            this.txtDesIRPF.TabIndex = 16;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Location = new System.Drawing.Point(124, 213);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(181, 20);
            this.txtAliqIRPF.TabIndex = 17;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Location = new System.Drawing.Point(124, 251);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(181, 20);
            this.txtSalFamilia.TabIndex = 18;
            // 
            // txtLiquido
            // 
            this.txtLiquido.Location = new System.Drawing.Point(124, 284);
            this.txtLiquido.Name = "txtLiquido";
            this.txtLiquido.Size = new System.Drawing.Size(181, 20);
            this.txtLiquido.TabIndex = 19;
            // 
            // mskbxNome
            // 
            this.mskbxNome.Location = new System.Drawing.Point(125, 10);
            this.mskbxNome.Name = "mskbxNome";
            this.mskbxNome.Size = new System.Drawing.Size(328, 20);
            this.mskbxNome.TabIndex = 21;
            // 
            // txtBruto
            // 
            this.txtBruto.Location = new System.Drawing.Point(124, 47);
            this.txtBruto.Name = "txtBruto";
            this.txtBruto.Size = new System.Drawing.Size(128, 20);
            this.txtBruto.TabIndex = 22;
            this.txtBruto.Validated += new System.EventHandler(this.txtBruto_Validated);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 333);
            this.Controls.Add(this.txtBruto);
            this.Controls.Add(this.mskbxNome);
            this.Controls.Add(this.txtLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtDesIRPF);
            this.Controls.Add(this.lblDesIRPF);
            this.Controls.Add(this.txtDesINSS);
            this.Controls.Add(this.lblDesINSS);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblNFilhos);
            this.Controls.Add(this.lblBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblBruto;
        private System.Windows.Forms.Label lblNFilhos;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.Label lblDesINSS;
        private System.Windows.Forms.TextBox txtDesINSS;
        private System.Windows.Forms.Label lblDesIRPF;
        private System.Windows.Forms.TextBox txtDesIRPF;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxNome;
        private System.Windows.Forms.TextBox txtBruto;
    }
}

